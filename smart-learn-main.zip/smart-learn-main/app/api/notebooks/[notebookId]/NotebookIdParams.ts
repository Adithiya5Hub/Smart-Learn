import {Notebook} from "@/types/Notebook";

export interface NotebookIdParams {
    notebookId: Notebook["id"]
}