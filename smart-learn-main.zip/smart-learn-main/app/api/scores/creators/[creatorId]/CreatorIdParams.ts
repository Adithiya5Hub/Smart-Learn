export interface CreatorIdParams {
    creatorId: string;
}