import {NotebookRow} from "@/cosmosPostgres/types";

export interface NotebookIdParams {
    notebookId: NotebookRow["id"]
}