export interface NoteIdParams {
    noteId: number;
}