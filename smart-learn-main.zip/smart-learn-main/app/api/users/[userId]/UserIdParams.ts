export interface UserIdParams {
    userId: string;
}