export interface NotebookIndexRow {
    id: string;
    name: string;
}