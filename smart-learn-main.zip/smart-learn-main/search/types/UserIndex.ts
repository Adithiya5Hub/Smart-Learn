export interface UserIndexRow {
    id: string;
    name: string;
    username: string;
    profile_picture_url: string;
}