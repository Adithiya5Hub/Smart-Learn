export interface StudyGuide {
    studyGuide: string;
}