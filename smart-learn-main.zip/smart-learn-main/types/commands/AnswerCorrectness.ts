export interface AnswerCorrectness {
    correct: boolean;
    explanation: string;
}