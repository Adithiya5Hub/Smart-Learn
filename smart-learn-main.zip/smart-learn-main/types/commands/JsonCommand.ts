import {CommandTags} from "@/prompts";

export interface JsonCommand {
    tag: CommandTags,
    content: string
}