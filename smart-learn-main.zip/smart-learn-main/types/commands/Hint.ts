export interface Hint {
    hint: string;
}