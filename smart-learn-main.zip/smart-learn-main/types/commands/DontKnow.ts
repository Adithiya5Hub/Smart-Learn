export interface DontKnow {
    explanation: string;
}