export interface TextBasedQuestion {
    question: string;
}