export const USERS_TABLE = "Users";
export const NOTEBOOKS_TABLE = "Notebooks";
export const NOTES_TABLE = "Notes";
export const SCORES_TABLE = "Scores";
export const TAG_TYPES_TABLE = "TagTypes";
export const NOTEBOOK_TAGS_TABLE = "NotebookTags";
